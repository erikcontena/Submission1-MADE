package com.contena.core.adapter

interface ClickItemCallback {
    fun <T> onClick(data: T)
}
